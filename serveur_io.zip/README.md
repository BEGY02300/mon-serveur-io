
# Serveur .io prêt pour Railway

- Express + Socket.io configurés
- Déployable en 1 clic sur Railway.app
- Modifie `server.js` pour ton gameplay personnalisé
