/*
  # Création des tables pour les projets et fichiers
  
  1. Nouvelles Tables
    - `projects` : Stocke les projets des utilisateurs
    - `files` : Stocke les fichiers de chaque projet
  
  2. Sécurité
    - RLS activé sur toutes les tables
    - Politiques pour la lecture/écriture
*/

-- Table des projets
CREATE TABLE IF NOT EXISTS projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  is_public boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE projects ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read their own projects"
  ON projects
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own projects"
  ON projects
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own projects"
  ON projects
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- Table des fichiers
CREATE TABLE IF NOT EXISTS files (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid REFERENCES projects(id) ON DELETE CASCADE,
  name text NOT NULL,
  content text NOT NULL,
  language text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE files ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read files from their projects"
  ON files
  FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM projects 
    WHERE projects.id = files.project_id 
    AND projects.user_id = auth.uid()
  ));

CREATE POLICY "Users can create files in their projects"
  ON files
  FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (
    SELECT 1 FROM projects 
    WHERE projects.id = files.project_id 
    AND projects.user_id = auth.uid()
  ));

CREATE POLICY "Users can update files in their projects"
  ON files
  FOR UPDATE
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM projects 
    WHERE projects.id = files.project_id 
    AND projects.user_id = auth.uid()
  ));