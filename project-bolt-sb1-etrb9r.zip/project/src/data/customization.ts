import { CustomizationItem, CustomizationType } from '../types/user';

export const customizationItems: CustomizationItem[] = [
  // Avatars
  {
    id: 'avatar_1',
    name: 'Avatar Classique',
    type: CustomizationType.Avatar,
    price: 0,
    imageUrl: '/assets/avatars/classic.png',
    requiredGrade: 'free'
  },
  {
    id: 'avatar_2',
    name: 'Avatar Développeur',
    type: CustomizationType.Avatar,
    price: 500,
    imageUrl: '/assets/avatars/developer.png',
    requiredGrade: 'starter'
  },
  {
    id: 'avatar_3',
    name: 'Avatar Hacker',
    type: CustomizationType.Avatar,
    price: 1000,
    imageUrl: '/assets/avatars/hacker.png',
    requiredGrade: 'bronze'
  },

  // Badges
  {
    id: 'badge_1',
    name: 'Badge Débutant',
    type: CustomizationType.Badge,
    price: 0,
    imageUrl: '/assets/badges/beginner.png',
    requiredGrade: 'free'
  },
  {
    id: 'badge_2',
    name: 'Badge Pro',
    type: CustomizationType.Badge,
    price: 1500,
    imageUrl: '/assets/badges/pro.png',
    requiredGrade: 'silver'
  },
  {
    id: 'badge_3',
    name: 'Badge Expert',
    type: CustomizationType.Badge,
    price: 3000,
    imageUrl: '/assets/badges/expert.png',
    requiredGrade: 'gold'
  },

  // Cadres
  {
    id: 'frame_1',
    name: 'Cadre Simple',
    type: CustomizationType.Frame,
    price: 0,
    imageUrl: '/assets/frames/simple.png',
    requiredGrade: 'free'
  },
  {
    id: 'frame_2',
    name: 'Cadre Doré',
    type: CustomizationType.Frame,
    price: 2000,
    imageUrl: '/assets/frames/gold.png',
    requiredGrade: 'gold'
  },
  {
    id: 'frame_3',
    name: 'Cadre Animé',
    type: CustomizationType.Frame,
    price: 5000,
    imageUrl: '/assets/frames/animated.png',
    requiredGrade: 'diamond'
  },

  // Effets
  {
    id: 'effect_1',
    name: 'Effet Particules',
    type: CustomizationType.Effect,
    price: 1000,
    imageUrl: '/assets/effects/particles.png',
    requiredGrade: 'platinum'
  },
  {
    id: 'effect_2',
    name: 'Effet Aura',
    type: CustomizationType.Effect,
    price: 3000,
    imageUrl: '/assets/effects/aura.png',
    requiredGrade: 'master'
  },
  {
    id: 'effect_3',
    name: 'Effet Arc-en-ciel',
    type: CustomizationType.Effect,
    price: 10000,
    imageUrl: '/assets/effects/rainbow.png',
    requiredGrade: 'legend'
  }
];