import { UserGrade } from '../types/user';

export const grades: UserGrade[] = [
  {
    id: 'free',
    name: 'Novice',
    price: 0,
    features: [
      'Éditeur de code basique',
      'Qualité vidéo 720p',
      '1 projet simultané',
      'Stockage 100MB',
      'Thèmes de base'
    ],
    color: 'gray',
    customizationSlots: 1,
    maxProjects: 1,
    videoQuality: '720p',
    codeLanguages: ['javascript', 'html', 'css']
  },
  {
    id: 'starter',
    name: 'Débutant',
    price: 4.99,
    features: [
      'Éditeur de code avancé',
      'Qualité vidéo 1080p',
      '3 projets simultanés',
      'Stockage 500MB',
      'Débogueur intégré',
      'Chat communautaire'
    ],
    color: 'green',
    customizationSlots: 3,
    maxProjects: 3,
    videoQuality: '1080p',
    codeLanguages: ['javascript', 'html', 'css', 'python', 'typescript']
  },
  {
    id: 'bronze',
    name: 'Bronze',
    price: 9.99,
    features: [
      'Éditeur professionnel',
      'Qualité vidéo 1440p',
      '5 projets simultanés',
      'Stockage 1GB',
      'Tests automatisés',
      'Support par email',
      'Formations exclusives'
    ],
    color: 'yellow',
    customizationSlots: 5,
    maxProjects: 5,
    videoQuality: '1440p',
    codeLanguages: ['javascript', 'html', 'css', 'python', 'typescript', 'java', 'c++']
  },
  {
    id: 'silver',
    name: 'Argent',
    price: 14.99,
    features: [
      'Collaboration en temps réel',
      'Qualité vidéo 4K',
      '10 projets simultanés',
      'Stockage 3GB',
      'CI/CD intégré',
      'Support prioritaire',
      'Cours vidéo premium'
    ],
    color: 'gray',
    customizationSlots: 8,
    maxProjects: 10,
    videoQuality: '4k',
    codeLanguages: ['javascript', 'html', 'css', 'python', 'typescript', 'java', 'c++', 'rust', 'go']
  },
  {
    id: 'gold',
    name: 'Or',
    price: 19.99,
    features: [
      'Analyse de code IA',
      'Qualité vidéo 4K HDR',
      'Projets illimités',
      'Stockage 5GB',
      'Déploiement automatique',
      'Support 24/7',
      'Formations certifiantes'
    ],
    color: 'yellow',
    customizationSlots: 12,
    maxProjects: -1,
    videoQuality: '4k-hdr',
    codeLanguages: ['javascript', 'html', 'css', 'python', 'typescript', 'java', 'c++', 'rust', 'go', 'kotlin']
  },
  {
    id: 'platinum',
    name: 'Platine',
    price: 24.99,
    features: [
      'IA Assistant personnel',
      'Streaming 4K HDR',
      'Projets illimités',
      'Stockage 10GB',
      'Environnements cloud',
      'Support dédié',
      'Mentorat personnalisé'
    ],
    color: 'blue',
    customizationSlots: 15,
    maxProjects: -1,
    videoQuality: '4k-hdr',
    codeLanguages: ['*']
  },
  {
    id: 'diamond',
    name: 'Diamant',
    price: 29.99,
    features: [
      'IA Copilot avancé',
      'Streaming 8K',
      'Projets illimités',
      'Stockage 15GB',
      'Serveurs dédiés',
      'Support VIP',
      'Formation sur mesure'
    ],
    color: 'cyan',
    customizationSlots: 20,
    maxProjects: -1,
    videoQuality: '8k',
    codeLanguages: ['*']
  },
  {
    id: 'master',
    name: 'Maître',
    price: 39.99,
    features: [
      'IA Génération de code',
      'Streaming 8K HDR',
      'Projets illimités',
      'Stockage 20GB',
      'Infrastructure dédiée',
      'Support prioritaire 24/7',
      'Coaching personnalisé'
    ],
    color: 'purple',
    customizationSlots: 25,
    maxProjects: -1,
    videoQuality: '8k-hdr',
    codeLanguages: ['*']
  },
  {
    id: 'grandmaster',
    name: 'Grand Maître',
    price: 49.99,
    features: [
      'Suite IA complète',
      'Streaming 8K HDR+',
      'Projets illimités',
      'Stockage 50GB',
      'Cloud privé',
      'Support VIP 24/7',
      'Formation illimitée'
    ],
    color: 'red',
    customizationSlots: 50,
    maxProjects: -1,
    videoQuality: '8k-hdr-plus',
    codeLanguages: ['*']
  },
  {
    id: 'legend',
    name: 'Légende',
    price: 99.99,
    features: [
      'IA Personnalisée',
      'Qualité maximale',
      'Ressources illimitées',
      'Stockage illimité',
      'Infrastructure exclusive',
      'Support personnel',
      'Accès anticipé'
    ],
    color: 'rainbow',
    customizationSlots: -1,
    maxProjects: -1,
    videoQuality: 'max',
    codeLanguages: ['*']
  }
];