import { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { 
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  updateProfile as updateFirebaseProfile,
  signInAnonymously,
  PhoneAuthProvider,
  signInWithPhoneNumber,
  RecaptchaVerifier
} from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { auth, db, googleProvider } from '../lib/firebase';
import { User } from '../types/auth';
import { uploadImage } from '../lib/storage';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  loginWithPhone: (phoneNumber: string) => Promise<string>;
  verifyPhoneCode: (verificationId: string, code: string) => Promise<void>;
  loginAnonymously: () => Promise<void>;
  register: (email: string, password: string, username: string) => Promise<void>;
  logout: () => Promise<void>;
  updateProfile: (data: Partial<User>) => Promise<void>;
  uploadAvatar: (file: File) => Promise<string>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState({
    user: null as User | null,
    isAuthenticated: false,
    isLoading: true,
  });

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        try {
          const userDoc = await getDoc(doc(db, 'users', firebaseUser.uid));
          const userData = userDoc.data();
          
          const user: User = {
            id: firebaseUser.uid,
            email: firebaseUser.email!,
            username: userData?.username || firebaseUser.displayName || firebaseUser.email!.split('@')[0],
            avatarUrl: userData?.avatarUrl || firebaseUser.photoURL,
            phoneNumber: userData?.phoneNumber || firebaseUser.phoneNumber,
            recoveryEmail: userData?.recoveryEmail,
            grade: userData?.grade || 'free',
            createdAt: userData?.createdAt?.toDate() || new Date(),
            coins: userData?.coins || 0,
            experience: userData?.experience || 0,
            level: userData?.level || 1,
            customization: userData?.customization || {
              activeItems: [],
              ownedItems: []
            }
          };

          setState({ user, isAuthenticated: true, isLoading: false });
        } catch (error) {
          console.error('Error fetching user data:', error);
          setState({ user: null, isAuthenticated: false, isLoading: false });
        }
      } else {
        setState({ user: null, isAuthenticated: false, isLoading: false });
      }
    });

    return () => unsubscribe();
  }, []);

  const login = async (email: string, password: string) => {
    const { user: firebaseUser } = await signInWithEmailAndPassword(auth, email, password);
    await updateUserProfile(firebaseUser);
  };

  const loginWithGoogle = async () => {
    const { user: firebaseUser } = await signInWithPopup(auth, googleProvider);
    await updateUserProfile(firebaseUser);
  };

  const loginWithPhone = async (phoneNumber: string) => {
    const recaptchaVerifier = new RecaptchaVerifier(auth, 'recaptcha-container', {
      size: 'invisible',
    });

    const confirmationResult = await signInWithPhoneNumber(auth, phoneNumber, recaptchaVerifier);
    return confirmationResult.verificationId;
  };

  const verifyPhoneCode = async (verificationId: string, code: string) => {
    const credential = PhoneAuthProvider.credential(verificationId, code);
    const { user: firebaseUser } = await auth.signInWithCredential(credential);
    await updateUserProfile(firebaseUser);
  };

  const loginAnonymously = async () => {
    const { user: firebaseUser } = await signInAnonymously(auth);
    await updateUserProfile(firebaseUser);
  };

  const register = async (email: string, password: string, username: string) => {
    const { user: firebaseUser } = await createUserWithEmailAndPassword(auth, email, password);
    await updateFirebaseProfile(firebaseUser, { displayName: username });
    await updateUserProfile(firebaseUser, { username });
  };

  const logout = async () => {
    await signOut(auth);
  };

  const updateUserProfile = async (firebaseUser: any, additionalData?: Partial<User>) => {
    const userRef = doc(db, 'users', firebaseUser.uid);
    const userData = {
      username: additionalData?.username || firebaseUser.displayName || firebaseUser.email?.split('@')[0],
      email: firebaseUser.email,
      phoneNumber: firebaseUser.phoneNumber,
      avatarUrl: additionalData?.avatarUrl || firebaseUser.photoURL,
      updatedAt: new Date(),
      ...additionalData
    };

    await setDoc(userRef, {
      ...userData,
      createdAt: new Date(),
      grade: 'free',
      coins: 0,
      experience: 0,
      level: 1,
      customization: {
        activeItems: [],
        ownedItems: []
      }
    }, { merge: true });
  };

  const uploadAvatar = async (file: File): Promise<string> => {
    if (!state.user) throw new Error('User not authenticated');
    
    const avatarUrl = await uploadImage(file, `avatars/${state.user.id}`);
    
    await updateFirebaseProfile(auth.currentUser!, {
      photoURL: avatarUrl
    });
    
    await setDoc(doc(db, 'users', state.user.id), {
      avatarUrl,
      updatedAt: new Date()
    }, { merge: true });
    
    return avatarUrl;
  };

  const updateProfile = async (data: Partial<User>) => {
    if (!state.user) throw new Error('User not authenticated');
    
    if (auth.currentUser) {
      if (data.username) {
        await updateFirebaseProfile(auth.currentUser, {
          displayName: data.username
        });
      }
    }
    
    await setDoc(doc(db, 'users', state.user.id), {
      ...data,
      updatedAt: new Date()
    }, { merge: true });
    
    setState(prev => ({
      ...prev,
      user: prev.user ? { ...prev.user, ...data } : null,
    }));
  };

  return (
    <AuthContext.Provider value={{ 
      ...state, 
      login,
      loginWithGoogle,
      loginWithPhone,
      verifyPhoneCode,
      loginAnonymously,
      register,
      logout,
      updateProfile,
      uploadAvatar
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};