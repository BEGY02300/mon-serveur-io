import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './components/layout/Navbar';
import LoginForm from './components/auth/LoginForm';
import RegisterForm from './components/auth/RegisterForm';
import ForgotPasswordForm from './components/auth/ForgotPasswordForm';
import ProfilePage from './components/profile/ProfilePage';
import CodeEditor from './components/code/CodeEditor';
import ShowcasePage from './components/showcase/ShowcasePage';
import SharePage from './components/share/SharePage';
import RequireAuth from './components/auth/RequireAuth';
import { AuthProvider } from './context/AuthContext';

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="min-h-screen bg-gray-50">
          <Navbar />
          <main>
            <Routes>
              <Route path="/" element={<ShowcasePage />} />
              <Route path="/login" element={
                <div className="flex justify-center py-8">
                  <LoginForm />
                </div>
              } />
              <Route path="/register" element={
                <div className="flex justify-center py-8">
                  <RegisterForm />
                </div>
              } />
              <Route path="/forgot-password" element={
                <div className="flex justify-center py-8">
                  <ForgotPasswordForm />
                </div>
              } />
              <Route path="/profile" element={
                <RequireAuth>
                  <ProfilePage />
                </RequireAuth>
              } />
              <Route path="/editor" element={
                <RequireAuth>
                  <CodeEditor />
                </RequireAuth>
              } />
              <Route path="/share" element={
                <RequireAuth>
                  <SharePage />
                </RequireAuth>
              } />
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </main>
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;