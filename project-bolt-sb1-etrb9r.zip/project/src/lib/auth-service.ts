import { 
  signInWithEmailAndPassword, 
  signInWithPopup,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  updateProfile
} from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { auth, db, googleProvider, githubProvider } from './firebase';
import { User } from '../types/auth';

export class AuthService {
  static async loginWithEmail(email: string, password: string): Promise<User> {
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      return this.getUserData(userCredential.user.uid);
    } catch (error: any) {
      throw this.handleAuthError(error);
    }
  }

  static async loginWithGoogle() {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      await this.createUserProfile(result.user);
      return this.getUserData(result.user.uid);
    } catch (error: any) {
      throw this.handleAuthError(error);
    }
  }

  static async loginWithGithub() {
    try {
      const result = await signInWithPopup(auth, githubProvider);
      await this.createUserProfile(result.user);
      return this.getUserData(result.user.uid);
    } catch (error: any) {
      throw this.handleAuthError(error);
    }
  }

  static async register(email: string, password: string, username: string): Promise<User> {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;

      // Mise à jour du profil utilisateur
      await updateProfile(user, {
        displayName: username,
        photoURL: `https://ui-avatars.com/api/?name=${encodeURIComponent(username)}&background=random`
      });

      // Création du profil dans Firestore
      await this.createUserProfile(user, username);
      
      return this.getUserData(user.uid);
    } catch (error: any) {
      throw this.handleAuthError(error);
    }
  }

  static async resetPassword(email: string): Promise<void> {
    try {
      await sendPasswordResetEmail(auth, email);
    } catch (error: any) {
      throw this.handleAuthError(error);
    }
  }

  private static async createUserProfile(user: any, username?: string) {
    const userRef = doc(db, 'users', user.uid);
    const userData = {
      username: username || user.displayName || user.email?.split('@')[0],
      email: user.email,
      avatarUrl: user.photoURL || `https://ui-avatars.com/api/?name=${encodeURIComponent(username || user.displayName || 'User')}&background=random`,
      lastLoginAt: new Date(),
      updatedAt: new Date()
    };

    const userDoc = await getDoc(userRef);
    if (!userDoc.exists()) {
      await setDoc(userRef, {
        ...userData,
        createdAt: new Date()
      });
    } else {
      await setDoc(userRef, userData, { merge: true });
    }
  }

  private static async getUserData(uid: string): Promise<User> {
    const userDoc = await getDoc(doc(db, 'users', uid));
    const userData = userDoc.data();
    
    if (!userData) {
      throw new Error('Utilisateur non trouvé');
    }

    return {
      id: uid,
      email: userData.email,
      username: userData.username,
      avatarUrl: userData.avatarUrl,
      createdAt: userData.createdAt.toDate(),
    };
  }

  private static handleAuthError(error: any): Error {
    const errorMessages: Record<string, string> = {
      'auth/user-not-found': 'Aucun utilisateur trouvé avec cet email',
      'auth/wrong-password': 'Mot de passe incorrect',
      'auth/email-already-in-use': 'Cet email est déjà utilisé',
      'auth/weak-password': 'Le mot de passe doit contenir au moins 6 caractères',
      'auth/invalid-email': 'Format d\'email invalide',
      'auth/popup-closed-by-user': 'La fenêtre de connexion a été fermée',
      'auth/cancelled-popup-request': 'Une seule fenêtre de connexion peut être ouverte à la fois',
      'auth/popup-blocked': 'La fenêtre popup a été bloquée par le navigateur',
      'auth/operation-not-allowed': 'Cette méthode de connexion n\'est pas activée',
      'auth/account-exists-with-different-credential': 'Un compte existe déjà avec une autre méthode de connexion'
    };

    return new Error(errorMessages[error.code] || error.message || 'Une erreur est survenue');
  }
}