import { User } from '../types/auth';

export const generateDefaultAvatar = (username: string) => {
  const colors = ['FF6B6B', '4ECDC4', '45B7D1', '96CEB4', 'FFEEAD'];
  const randomColor = colors[Math.floor(Math.random() * colors.length)];
  return `https://ui-avatars.com/api/?name=${encodeURIComponent(username)}&background=${randomColor}&color=fff`;
};

export const formatUserData = (userData: any): User => {
  return {
    id: userData.uid,
    email: userData.email || '',
    username: userData.displayName || userData.email?.split('@')[0] || 'Utilisateur',
    avatarUrl: userData.photoURL || generateDefaultAvatar(userData.displayName || 'Utilisateur'),
    createdAt: userData.metadata?.creationTime ? new Date(userData.metadata.creationTime) : new Date(),
  };
};

export const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

export const validatePassword = (password: string): boolean => {
  return password.length >= 6;
};

export const validateUsername = (username: string): boolean => {
  return username.length >= 3 && username.length <= 20 && /^[a-zA-Z0-9_-]+$/.test(username);
};