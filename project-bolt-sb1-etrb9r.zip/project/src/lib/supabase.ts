import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export const getProjectsForUser = async (userId: string) => {
  const { data, error } = await supabase
    .from('projects')
    .select(`
      *,
      files (*)
    `)
    .eq('user_id', userId)
    .order('updated_at', { ascending: false });

  if (error) throw error;
  return data;
};

export const createProject = async (userId: string, name: string, description?: string) => {
  const { data, error } = await supabase
    .from('projects')
    .insert([
      { user_id: userId, name, description }
    ])
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const saveFile = async (projectId: string, name: string, content: string, language: string) => {
  const { data, error } = await supabase
    .from('files')
    .insert([
      { project_id: projectId, name, content, language }
    ])
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const updateFile = async (fileId: string, content: string) => {
  const { data, error } = await supabase
    .from('files')
    .update({ content, updated_at: new Date().toISOString() })
    .eq('id', fileId)
    .select()
    .single();

  if (error) throw error;
  return data;
};