import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, GithubAuthProvider, connectAuthEmulator, browserPopupRedirectResolver } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: "AIzaSyBODslZ0PEgPfaoYd9Cmalvg7ubiwnO6nI",
  authDomain: "site-web-2-3021e.firebaseapp.com",
  projectId: "site-web-2-3021e",
  storageBucket: "site-web-2-3021e.appspot.com",
  messagingSenderId: "992702393992",
  appId: "1:992702393992:web:cbadca1f8ecb8b134db93d",
  measurementId: "G-EQ8LQVWX7N"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// Configuration des providers
const googleProvider = new GoogleAuthProvider();
const githubProvider = new GithubAuthProvider();

// Configuration supplémentaire
auth.useDeviceLanguage();
googleProvider.setCustomParameters({
  prompt: 'select_account',
  display: 'popup'
});
githubProvider.setCustomParameters({
  prompt: 'select_account',
  display: 'popup'
});

// Initialisation des autres services
const db = getFirestore(app);
const storage = getStorage(app);

// En mode développement, utiliser l'émulateur si disponible
if (import.meta.env.DEV) {
  try {
    connectAuthEmulator(auth, 'http://localhost:9099');
  } catch (error) {
    console.warn('Auth emulator not running');
  }
}

export {
  auth,
  db,
  storage,
  googleProvider,
  githubProvider,
  browserPopupRedirectResolver
};