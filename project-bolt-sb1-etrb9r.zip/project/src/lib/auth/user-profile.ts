import { User as FirebaseUser, updateProfile } from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { User } from '../../types/auth';
import { generateAvatarUrl } from '../utils';

export const createOrUpdateUserProfile = async (
  firebaseUser: FirebaseUser,
  additionalData?: Partial<User>
) => {
  const userRef = doc(db, 'users', firebaseUser.uid);
  const username = additionalData?.username || firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'Utilisateur';
  
  const userData = {
    username,
    email: firebaseUser.email,
    avatarUrl: additionalData?.avatarUrl || firebaseUser.photoURL || generateAvatarUrl(username),
    updatedAt: new Date(),
  };

  if (firebaseUser.displayName !== username) {
    await updateProfile(firebaseUser, { displayName: username });
  }

  await setDoc(userRef, {
    ...userData,
    createdAt: new Date(),
  }, { merge: true });

  return userData;
};

export const getUserProfile = async (userId: string): Promise<User | null> => {
  try {
    const userDoc = await getDoc(doc(db, 'users', userId));
    if (!userDoc.exists()) return null;

    const data = userDoc.data();
    return {
      id: userId,
      email: data.email,
      username: data.username,
      avatarUrl: data.avatarUrl,
      createdAt: data.createdAt.toDate(),
    };
  } catch (error) {
    console.error('Error fetching user profile:', error);
    return null;
  }
};