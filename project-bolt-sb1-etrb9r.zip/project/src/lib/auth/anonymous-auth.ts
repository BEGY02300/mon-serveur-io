import { signInAnonymously } from 'firebase/auth';
import { auth } from '../firebase';
import { createOrUpdateUserProfile } from './user-profile';
import { AuthError } from '../../types/auth';

export const loginAnonymously = async () => {
  try {
    const { user: firebaseUser } = await signInAnonymously(auth);
    await createOrUpdateUserProfile(firebaseUser, {
      username: `Anonyme_${Math.random().toString(36).slice(2, 7)}`
    });
    return firebaseUser;
  } catch (error) {
    throw handleAnonymousAuthError(error as AuthError);
  }
};

const handleAnonymousAuthError = (error: AuthError): Error => {
  const errorMessages: Record<string, string> = {
    'auth/operation-not-allowed': 'La connexion anonyme n\'est pas activée',
    'auth/admin-restricted-operation': 'Opération non autorisée'
  };

  return new Error(errorMessages[error.code] || error.message || 'Une erreur est survenue');
};