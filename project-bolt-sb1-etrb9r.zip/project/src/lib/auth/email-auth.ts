import { signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';
import { auth } from '../firebase';
import { createOrUpdateUserProfile } from './user-profile';
import { validateEmail, validatePassword } from '../validation';
import { AuthError } from '../../types/auth';

export const loginWithEmail = async (email: string, password: string) => {
  if (!validateEmail(email).isValid) {
    throw new Error('Email invalide');
  }

  if (!validatePassword(password).isValid) {
    throw new Error('Mot de passe invalide');
  }

  try {
    const { user: firebaseUser } = await signInWithEmailAndPassword(auth, email, password);
    return firebaseUser;
  } catch (error) {
    throw handleEmailAuthError(error as AuthError);
  }
};

export const registerWithEmail = async (email: string, password: string, username: string) => {
  if (!validateEmail(email).isValid) {
    throw new Error('Email invalide');
  }

  if (!validatePassword(password).isValid) {
    throw new Error('Mot de passe invalide');
  }

  try {
    const { user: firebaseUser } = await createUserWithEmailAndPassword(auth, email, password);
    await createOrUpdateUserProfile(firebaseUser, { username });
    return firebaseUser;
  } catch (error) {
    throw handleEmailAuthError(error as AuthError);
  }
};

const handleEmailAuthError = (error: AuthError): Error => {
  const errorMessages: Record<string, string> = {
    'auth/user-not-found': 'Aucun utilisateur trouvé avec cet email',
    'auth/wrong-password': 'Mot de passe incorrect',
    'auth/email-already-in-use': 'Cet email est déjà utilisé',
    'auth/invalid-email': 'Format d\'email invalide',
    'auth/too-many-requests': 'Trop de tentatives. Veuillez réessayer plus tard',
  };

  return new Error(errorMessages[error.code] || error.message || 'Une erreur est survenue');
};