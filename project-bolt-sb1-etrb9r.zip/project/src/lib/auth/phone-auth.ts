import { PhoneAuthProvider, signInWithPhoneNumber, RecaptchaVerifier } from 'firebase/auth';
import { auth } from '../firebase';
import { createOrUpdateUserProfile } from './user-profile';
import { validatePhoneNumber } from '../validation';
import { AuthError } from '../../types/auth';

export const loginWithPhone = async (phoneNumber: string) => {
  const validation = validatePhoneNumber(phoneNumber);
  if (!validation.isValid) {
    throw new Error(validation.message);
  }

  try {
    const recaptchaVerifier = new RecaptchaVerifier(auth, 'recaptcha-container', {
      size: 'invisible',
    });

    const confirmationResult = await signInWithPhoneNumber(auth, phoneNumber, recaptchaVerifier);
    return confirmationResult.verificationId;
  } catch (error) {
    throw handlePhoneAuthError(error as AuthError);
  }
};

export const verifyPhoneCode = async (verificationId: string, code: string) => {
  try {
    const credential = PhoneAuthProvider.credential(verificationId, code);
    const { user: firebaseUser } = await auth.signInWithCredential(credential);
    await createOrUpdateUserProfile(firebaseUser);
    return firebaseUser;
  } catch (error) {
    throw handlePhoneAuthError(error as AuthError);
  }
};

const handlePhoneAuthError = (error: AuthError): Error => {
  const errorMessages: Record<string, string> = {
    'auth/invalid-verification-code': 'Code de vérification invalide',
    'auth/code-expired': 'Le code a expiré',
    'auth/invalid-phone-number': 'Numéro de téléphone invalide',
    'auth/missing-verification-code': 'Code de vérification manquant',
    'auth/quota-exceeded': 'Quota dépassé, veuillez réessayer plus tard',
  };

  return new Error(errorMessages[error.code] || error.message || 'Une erreur est survenue');
};