import { signInWithPopup } from 'firebase/auth';
import { auth, googleProvider, githubProvider } from '../firebase';
import { createOrUpdateUserProfile } from './user-profile';
import { AuthError } from '../../types/auth';

export const loginWithGoogle = async () => {
  try {
    const { user: firebaseUser } = await signInWithPopup(auth, googleProvider);
    await createOrUpdateUserProfile(firebaseUser);
    return firebaseUser;
  } catch (error) {
    throw handleSocialAuthError(error as AuthError);
  }
};

export const loginWithGithub = async () => {
  try {
    const { user: firebaseUser } = await signInWithPopup(auth, githubProvider);
    await createOrUpdateUserProfile(firebaseUser);
    return firebaseUser;
  } catch (error) {
    throw handleSocialAuthError(error as AuthError);
  }
};

const handleSocialAuthError = (error: AuthError): Error => {
  const errorMessages: Record<string, string> = {
    'auth/popup-closed-by-user': 'La fenêtre de connexion a été fermée',
    'auth/cancelled-popup-request': 'Une seule fenêtre de connexion peut être ouverte à la fois',
    'auth/popup-blocked': 'La fenêtre popup a été bloquée par le navigateur',
    'auth/account-exists-with-different-credential': 'Un compte existe déjà avec une autre méthode de connexion'
  };

  return new Error(errorMessages[error.code] || error.message || 'Une erreur est survenue');
};