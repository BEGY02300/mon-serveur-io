import { User as FirebaseUser } from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { db } from './firebase';
import { User } from '../types/auth';

export const convertFirebaseUser = async (firebaseUser: FirebaseUser): Promise<User> => {
  try {
    const userDoc = await getDoc(doc(db, 'users', firebaseUser.uid));
    const userData = userDoc.data();

    return {
      id: firebaseUser.uid,
      email: firebaseUser.email!,
      username: userData?.username || firebaseUser.displayName || firebaseUser.email!.split('@')[0],
      avatarUrl: userData?.avatarUrl || firebaseUser.photoURL || `https://ui-avatars.com/api/?name=${encodeURIComponent(userData?.username || 'User')}`,
      createdAt: userData?.createdAt?.toDate() || new Date(),
    };
  } catch (error) {
    // If offline or error, return minimal user object
    return {
      id: firebaseUser.uid,
      email: firebaseUser.email!,
      username: firebaseUser.displayName || firebaseUser.email!.split('@')[0],
      avatarUrl: firebaseUser.photoURL || `https://ui-avatars.com/api/?name=${encodeURIComponent(firebaseUser.displayName || 'User')}`,
      createdAt: new Date(),
    };
  }
};

export const createOrUpdateUserProfile = async (
  firebaseUser: FirebaseUser,
  additionalData?: Partial<User>
) => {
  try {
    const userRef = doc(db, 'users', firebaseUser.uid);
    const userData = {
      username: additionalData?.username || firebaseUser.displayName || firebaseUser.email?.split('@')[0],
      email: firebaseUser.email,
      avatarUrl: additionalData?.avatarUrl || firebaseUser.photoURL || `https://ui-avatars.com/api/?name=${encodeURIComponent(additionalData?.username || 'User')}`,
      updatedAt: new Date(),
    };

    await setDoc(userRef, {
      ...userData,
      createdAt: new Date(),
    }, { merge: true });

    return userData;
  } catch (error) {
    console.error('Error updating user profile:', error);
    throw error;
  }
};