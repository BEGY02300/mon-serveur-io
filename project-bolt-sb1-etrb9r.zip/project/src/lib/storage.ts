import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { storage } from './firebase';

export const uploadImage = async (file: File, path: string): Promise<string> => {
  try {
    // Création d'une référence unique pour l'image
    const timestamp = Date.now();
    const filename = `${timestamp}-${file.name}`;
    const storageRef = ref(storage, `${path}/${filename}`);

    // Upload du fichier
    await uploadBytes(storageRef, file);

    // Récupération de l'URL de téléchargement
    const downloadURL = await getDownloadURL(storageRef);
    return downloadURL;
  } catch (error) {
    console.error('Erreur lors du téléchargement de l\'image:', error);
    throw new Error('Erreur lors du téléchargement de l\'image');
  }
};