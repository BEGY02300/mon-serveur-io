export const validateEmail = (email: string): { isValid: boolean; message?: string } => {
  if (!email) {
    return { isValid: false, message: 'L\'email est requis' };
  }
  
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return { isValid: false, message: 'Format d\'email invalide' };
  }
  
  return { isValid: true };
};

export const validatePassword = (password: string): { isValid: boolean; message?: string } => {
  if (!password) {
    return { isValid: false, message: 'Le mot de passe est requis' };
  }
  
  if (password.length < 6) {
    return { isValid: false, message: 'Le mot de passe doit contenir au moins 6 caractères' };
  }
  
  return { isValid: true };
};

export const validateUsername = (username: string): { isValid: boolean; message?: string } => {
  if (!username) {
    return { isValid: false, message: 'Le nom d\'utilisateur est requis' };
  }
  
  if (username.length < 3) {
    return { isValid: false, message: 'Le nom d\'utilisateur doit contenir au moins 3 caractères' };
  }
  
  if (username.length > 20) {
    return { isValid: false, message: 'Le nom d\'utilisateur ne doit pas dépasser 20 caractères' };
  }
  
  const usernameRegex = /^[a-zA-Z0-9_-]+$/;
  if (!usernameRegex.test(username)) {
    return { isValid: false, message: 'Le nom d\'utilisateur ne peut contenir que des lettres, chiffres, tirets et underscores' };
  }
  
  return { isValid: true };
};

export const validatePhoneNumber = (phoneNumber: string): { isValid: boolean; message?: string } => {
  if (!phoneNumber) {
    return { isValid: false, message: 'Le numéro de téléphone est requis' };
  }

  // Format international: +33612345678
  const phoneRegex = /^\+[1-9]\d{1,14}$/;
  if (!phoneRegex.test(phoneNumber)) {
    return { 
      isValid: false, 
      message: 'Format de numéro invalide. Utilisez le format international (ex: +33612345678)' 
    };
  }

  return { isValid: true };
};