import { loadStripe } from '@stripe/stripe-js';

const stripePromise = loadStripe('your_publishable_key');

export const initiateSubscription = async (priceId: string) => {
  const stripe = await stripePromise;
  if (!stripe) throw new Error('Stripe not initialized');

  // Ici, vous devriez avoir un endpoint backend qui crée la session de paiement
  const response = await fetch('/api/create-subscription', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ priceId }),
  });

  const session = await response.json();
  
  const { error } = await stripe.redirectToCheckout({
    sessionId: session.id,
  });

  if (error) {
    throw new Error(error.message);
  }
};