import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, connectAuthEmulator } from 'firebase/auth';
import { getFirestore, enableIndexedDbPersistence } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';
import { getAnalytics } from 'firebase/analytics';

const firebaseConfig = {
  apiKey: "AIzaSyDGUXX7J4m0SLBlq2nQyiq6aConxBezrDU",
  authDomain: "siteweb-721ed.firebaseapp.com",
  projectId: "siteweb-721ed",
  storageBucket: "siteweb-721ed.firebasestorage.app",
  messagingSenderId: "224755625406",
  appId: "1:224755625406:web:b5791b1a99a6ee55329def",
  measurementId: "G-NR4Y9DTMR6"
};

const app = initializeApp(firebaseConfig);

// Configuration des providers avec des options spécifiques
const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({
  prompt: 'select_account'
});

// Initialisation des services Firebase
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
export const analytics = getAnalytics(app);
export { googleProvider };

// Enable offline persistence
enableIndexedDbPersistence(db).catch((err) => {
  if (err.code === 'failed-precondition') {
    console.warn('Multiple tabs open, persistence can only be enabled in one tab at a time.');
  } else if (err.code === 'unimplemented') {
    console.warn('The current browser doesn\'t support offline persistence.');
  }
});

// Configuration de la langue de l'interface d'authentification
auth.useDeviceLanguage();

// En mode développement, utiliser l'émulateur si disponible
if (import.meta.env.DEV) {
  try {
    connectAuthEmulator(auth, 'http://localhost:9099');
  } catch (error) {
    console.warn('Auth emulator not running');
  }
}

export default app;