import { useState, useCallback } from 'react';
import { AuthService } from '../services/auth.service';
import { User } from '../types/auth';

export function useAuth() {
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleAuthOperation = async <T>(operation: () => Promise<T>): Promise<T | null> => {
    setError(null);
    setLoading(true);
    try {
      const result = await operation();
      return result;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Une erreur est survenue');
      return null;
    } finally {
      setLoading(false);
    }
  };

  const login = useCallback(async (email: string, password: string) => {
    return handleAuthOperation(() => AuthService.loginWithEmail(email, password));
  }, []);

  const loginWithGoogle = useCallback(async () => {
    return handleAuthOperation(() => AuthService.loginWithGoogle());
  }, []);

  const loginWithGithub = useCallback(async () => {
    return handleAuthOperation(() => AuthService.loginWithGithub());
  }, []);

  const register = useCallback(async (email: string, password: string, username: string) => {
    return handleAuthOperation(() => AuthService.registerWithEmail(email, password, username));
  }, []);

  const resetPassword = useCallback(async (email: string) => {
    return handleAuthOperation(async () => {
      await AuthService.resetPassword(email);
      return true;
    });
  }, []);

  return {
    error,
    loading,
    login,
    loginWithGoogle,
    loginWithGithub,
    register,
    resetPassword,
  };
}