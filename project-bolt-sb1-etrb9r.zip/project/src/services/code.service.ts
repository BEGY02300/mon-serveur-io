import { db } from '../lib/firebase';
import { 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  query, 
  where, 
  getDocs, 
  updateDoc, 
  orderBy, 
  limit 
} from 'firebase/firestore';
import { CodeSnippet, CodeShare } from '../types/code';
import { grades } from '../data/grades';

export class CodeService {
  static async saveCode(snippet: Partial<CodeSnippet>, userId: string): Promise<string> {
    try {
      const userDoc = await getDoc(doc(db, 'users', userId));
      const userData = userDoc.data();
      const userGrade = grades.find(g => g.id === userData?.grade);
      
      if (userGrade?.maxProjects !== -1) {
        const projectsQuery = query(
          collection(db, 'codeSnippets'),
          where('userId', '==', userId)
        );
        const projectsSnap = await getDocs(projectsQuery);
        
        if (projectsSnap.size >= userGrade!.maxProjects) {
          throw new Error(`Limite de ${userGrade!.maxProjects} projets atteinte pour votre grade`);
        }
      }

      if (!this.isLanguageAllowed(snippet.language!, userGrade!.codeLanguages)) {
        throw new Error('Ce langage n\'est pas disponible dans votre grade');
      }

      const snippetRef = doc(collection(db, 'codeSnippets'));
      const newSnippet: CodeSnippet = {
        id: snippetRef.id,
        userId,
        title: snippet.title || 'Sans titre',
        description: snippet.description || '',
        code: snippet.code || '',
        language: snippet.language || 'javascript',
        visibility: snippet.visibility || 'private',
        sharedWith: snippet.sharedWith || [],
        createdAt: new Date(),
        updatedAt: new Date(),
        likes: 0,
        views: 0
      };

      await setDoc(snippetRef, newSnippet);
      return snippetRef.id;
    } catch (error) {
      throw error;
    }
  }

  static async getUserSnippets(userId: string): Promise<CodeSnippet[]> {
    const snippetsQuery = query(
      collection(db, 'codeSnippets'),
      where('userId', '==', userId),
      orderBy('createdAt', 'desc')
    );
    
    const snippetsSnap = await getDocs(snippetsQuery);
    return snippetsSnap.docs.map(doc => ({
      ...doc.data(),
      id: doc.id,
      createdAt: doc.data().createdAt.toDate(),
      updatedAt: doc.data().updatedAt.toDate()
    })) as CodeSnippet[];
  }

  static async getPublicSnippets(limitCount: number = 20): Promise<CodeSnippet[]> {
    const snippetsQuery = query(
      collection(db, 'codeSnippets'),
      where('visibility', '==', 'public'),
      orderBy('createdAt', 'desc'),
      limit(limitCount)
    );
    
    const snippetsSnap = await getDocs(snippetsQuery);
    return snippetsSnap.docs.map(doc => ({
      ...doc.data(),
      id: doc.id,
      createdAt: doc.data().createdAt.toDate(),
      updatedAt: doc.data().updatedAt.toDate()
    })) as CodeSnippet[];
  }

  static async shareCode(snippetId: string, recipientId: string, permissions: 'read' | 'write'): Promise<void> {
    try {
      const shareRef = doc(collection(db, 'codeShares'));
      const share: CodeShare = {
        snippetId,
        recipientId,
        permissions,
        createdAt: new Date()
      };

      await setDoc(shareRef, share);
      
      const snippetRef = doc(db, 'codeSnippets', snippetId);
      await updateDoc(snippetRef, {
        sharedWith: [...(await this.getSharedUsers(snippetId)), recipientId]
      });
    } catch (error) {
      throw error;
    }
  }

  static async getSharedUsers(snippetId: string): Promise<string[]> {
    const sharesQuery = query(
      collection(db, 'codeShares'),
      where('snippetId', '==', snippetId)
    );
    const sharesSnap = await getDocs(sharesQuery);
    return sharesSnap.docs.map(doc => doc.data().recipientId);
  }

  private static isLanguageAllowed(language: string, allowedLanguages: string[]): boolean {
    return allowedLanguages.includes('*') || allowedLanguages.includes(language);
  }
}