import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  sendEmailVerification,
  signInWithPopup,
  User as FirebaseUser,
  AuthError
} from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { auth, db, googleProvider, githubProvider, browserPopupRedirectResolver } from '../lib/firebase-config';
import { User } from '../types/auth';

export class AuthService {
  static async loginWithEmail(email: string, password: string): Promise<User> {
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      return this.convertFirebaseUser(userCredential.user);
    } catch (error) {
      throw this.handleAuthError(error as AuthError);
    }
  }

  static async loginWithGoogle(): Promise<User> {
    try {
      const result = await signInWithPopup(auth, googleProvider, browserPopupRedirectResolver);
      await this.createOrUpdateUserProfile(result.user);
      return this.convertFirebaseUser(result.user);
    } catch (error) {
      throw this.handleAuthError(error as AuthError);
    }
  }

  static async loginWithGithub(): Promise<User> {
    try {
      const result = await signInWithPopup(auth, githubProvider, browserPopupRedirectResolver);
      await this.createOrUpdateUserProfile(result.user);
      return this.convertFirebaseUser(result.user);
    } catch (error) {
      throw this.handleAuthError(error as AuthError);
    }
  }

  static async registerWithEmail(email: string, password: string, username: string): Promise<User> {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;
      await this.createOrUpdateUserProfile(user, username);
      await sendEmailVerification(user);
      return this.convertFirebaseUser(user);
    } catch (error) {
      throw this.handleAuthError(error as AuthError);
    }
  }

  static async resetPassword(email: string): Promise<void> {
    try {
      await sendPasswordResetEmail(auth, email);
    } catch (error) {
      throw this.handleAuthError(error as AuthError);
    }
  }

  private static async createOrUpdateUserProfile(firebaseUser: FirebaseUser, username?: string): Promise<void> {
    const userDoc = doc(db, 'users', firebaseUser.uid);
    const userData = {
      username: username || firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'Utilisateur',
      email: firebaseUser.email,
      avatarUrl: firebaseUser.photoURL || `https://ui-avatars.com/api/?name=${encodeURIComponent(username || 'User')}`,
      lastLoginAt: new Date(),
      updatedAt: new Date()
    };

    if (!(await getDoc(userDoc)).exists()) {
      await setDoc(userDoc, {
        ...userData,
        createdAt: new Date()
      });
    } else {
      await setDoc(userDoc, userData, { merge: true });
    }
  }

  private static async convertFirebaseUser(firebaseUser: FirebaseUser): Promise<User> {
    const userDoc = await getDoc(doc(db, 'users', firebaseUser.uid));
    const userData = userDoc.data();

    return {
      id: firebaseUser.uid,
      email: firebaseUser.email!,
      username: userData?.username || firebaseUser.displayName || firebaseUser.email!.split('@')[0],
      avatarUrl: userData?.avatarUrl || firebaseUser.photoURL,
      createdAt: userData?.createdAt?.toDate() || new Date(),
      emailVerified: firebaseUser.emailVerified
    };
  }

  private static handleAuthError(error: AuthError): Error {
    const errorMessages: Record<string, string> = {
      'auth/user-not-found': 'Aucun utilisateur trouvé avec cet email',
      'auth/wrong-password': 'Mot de passe incorrect',
      'auth/email-already-in-use': 'Cet email est déjà utilisé',
      'auth/weak-password': 'Le mot de passe doit contenir au moins 6 caractères',
      'auth/invalid-email': 'Format d\'email invalide',
      'auth/too-many-requests': 'Trop de tentatives de connexion. Veuillez réessayer plus tard',
      'auth/popup-closed-by-user': 'La fenêtre de connexion a été fermée',
      'auth/cancelled-popup-request': 'Une seule fenêtre de connexion peut être ouverte à la fois',
      'auth/popup-blocked': 'La fenêtre popup a été bloquée par le navigateur'
    };

    return new Error(errorMessages[error.code] || error.message || 'Une erreur est survenue');
  }
}