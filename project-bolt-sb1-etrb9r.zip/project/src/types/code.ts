export interface CodeSnippet {
  id: string;
  userId: string;
  title: string;
  description: string;
  code: string;
  language: string;
  visibility: 'public' | 'private' | 'shared';
  sharedWith: string[];
  createdAt: Date;
  updatedAt: Date;
  likes: number;
  views: number;
}

export interface CodeShare {
  snippetId: string;
  recipientId: string;
  permissions: 'read' | 'write';
  createdAt: Date;
}