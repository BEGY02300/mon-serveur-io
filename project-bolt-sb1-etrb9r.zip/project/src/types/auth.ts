export interface User {
  id: string;
  email: string;
  username: string;
  avatarUrl?: string;
  phoneNumber?: string;
  recoveryEmail?: string;
  grade: string;
  createdAt: Date;
  coins: number;
  experience: number;
  level: number;
  customization: {
    activeItems: string[];
    ownedItems: string[];
  };
}