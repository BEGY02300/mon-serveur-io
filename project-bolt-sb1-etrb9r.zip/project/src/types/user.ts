export enum CustomizationType {
  Avatar = 'avatar',
  Badge = 'badge',
  Frame = 'frame',
  Effect = 'effect'
}

export interface CustomizationItem {
  id: string;
  name: string;
  type: CustomizationType;
  price: number;
  imageUrl: string;
  requiredGrade: string;
}

export interface UserGrade {
  id: string;
  name: string;
  price: number;
  features: string[];
  color: string;
  customizationSlots: number;
  maxProjects: number;
  videoQuality: string;
  codeLanguages: string[];
}

export interface UserProfile {
  id: string;
  email: string;
  username: string;
  avatarUrl?: string;
  phoneNumber?: string;
  recoveryEmail?: string;
  grade: string;
  createdAt: Date;
  coins: number;
  experience: number;
  level: number;
  customization: {
    activeItems: string[];
    ownedItems: string[];
  };
}

export interface GradeFeature {
  id: string;
  name: string;
  description: string;
  isEnabled: boolean;
}