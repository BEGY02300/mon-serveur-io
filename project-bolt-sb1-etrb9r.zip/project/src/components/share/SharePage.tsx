import { useState, useEffect } from 'react';
import { Share2, Search, Tag, MessageSquare, Globe, Lock, Users, Clock, Code } from 'lucide-react';
import Button from '../ui/Button';
import { CodeService } from '../../services/code.service';
import { SUPPORTED_LANGUAGES } from '../../constants/languages';
import { CodeSnippet } from '../../types/code';
import { useAuth } from '../../context/AuthContext';

export default function SharePage() {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState<string>('');
  const [sortBy, setSortBy] = useState<'recent' | 'popular'>('recent');
  const [mySnippets, setMySnippets] = useState<CodeSnippet[]>([]);
  const [publicSnippets, setPublicSnippets] = useState<CodeSnippet[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadSnippets();
    }
  }, [user]);

  const loadSnippets = async () => {
    try {
      setIsLoading(true);
      const [userSnippets, allPublicSnippets] = await Promise.all([
        CodeService.getUserSnippets(user!.id),
        CodeService.getPublicSnippets()
      ]);
      setMySnippets(userSnippets);
      setPublicSnippets(allPublicSnippets);
    } catch (error) {
      console.error('Error loading snippets:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const filteredSnippets = (snippets: CodeSnippet[]) => {
    return snippets.filter(snippet => {
      const matchesSearch = searchQuery.toLowerCase() === '' ||
        snippet.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        snippet.description.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesLanguage = selectedLanguage === '' || snippet.language === selectedLanguage;
      
      return matchesSearch && matchesLanguage;
    });
  };

  const sortSnippets = (snippets: CodeSnippet[]) => {
    return [...snippets].sort((a, b) => {
      if (sortBy === 'recent') {
        return b.createdAt.getTime() - a.createdAt.getTime();
      }
      return b.likes - a.likes;
    });
  };

  const renderSnippetCard = (snippet: CodeSnippet) => (
    <div key={snippet.id} className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xl font-semibold">{snippet.title}</h3>
        <div className="flex items-center space-x-2">
          {snippet.visibility === 'public' && <Globe className="w-4 h-4 text-green-500" />}
          {snippet.visibility === 'private' && <Lock className="w-4 h-4 text-red-500" />}
          {snippet.visibility === 'shared' && <Users className="w-4 h-4 text-blue-500" />}
        </div>
      </div>
      
      <p className="text-gray-600 mb-4">{snippet.description}</p>
      
      <div className="flex items-center space-x-4 mb-4">
        <span className="flex items-center text-sm text-gray-500">
          <Code className="w-4 h-4 mr-1" />
          {SUPPORTED_LANGUAGES[snippet.language as keyof typeof SUPPORTED_LANGUAGES]}
        </span>
        <span className="flex items-center text-sm text-gray-500">
          <Clock className="w-4 h-4 mr-1" />
          {new Date(snippet.createdAt).toLocaleDateString()}
        </span>
      </div>

      <div className="flex justify-between items-center">
        <div className="flex space-x-2">
          <Button variant="secondary" size="sm">
            Voir
          </Button>
          <Button variant="secondary" size="sm">
            <Share2 className="w-4 h-4" />
          </Button>
        </div>
        <div className="flex items-center space-x-4 text-sm text-gray-500">
          <span>{snippet.views} vues</span>
          <span>{snippet.likes} likes</span>
        </div>
      </div>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">Partage de Code</h2>
          <div className="flex space-x-4">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as 'recent' | 'popular')}
              className="px-4 py-2 border rounded-md"
            >
              <option value="recent">Plus récents</option>
              <option value="popular">Plus populaires</option>
            </select>
            <select
              value={selectedLanguage}
              onChange={(e) => setSelectedLanguage(e.target.value)}
              className="px-4 py-2 border rounded-md"
            >
              <option value="">Tous les langages</option>
              {Object.entries(SUPPORTED_LANGUAGES).map(([key, value]) => (
                <option key={key} value={key}>{value}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="relative mb-6">
          <input
            type="text"
            placeholder="Rechercher des snippets..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full px-4 py-2 pl-10 border rounded-md"
          />
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
        </div>
      </div>

      {isLoading ? (
        <div className="text-center py-8">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div>
          <p className="mt-4 text-gray-600">Chargement des snippets...</p>
        </div>
      ) : (
        <div className="space-y-8">
          {user && mySnippets.length > 0 && (
            <section>
              <h3 className="text-xl font-semibold mb-4">Mes Snippets</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {sortSnippets(filteredSnippets(mySnippets)).map(renderSnippetCard)}
              </div>
            </section>
          )}

          <section>
            <h3 className="text-xl font-semibold mb-4">Snippets Publics</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {sortSnippets(filteredSnippets(publicSnippets)).map(renderSnippetCard)}
            </div>
          </section>
        </div>
      )}
    </div>
  );
}