import { useState } from 'react';
import { X, Share2, Lock, Globe, Users } from 'lucide-react';
import Button from '../ui/Button';
import { CodeService } from '../../services/code.service';

interface ShareDialogProps {
  snippetId: string;
  isOpen: boolean;
  onClose: () => void;
}

export default function ShareDialog({ snippetId, isOpen, onClose }: ShareDialogProps) {
  const [visibility, setVisibility] = useState<'public' | 'private' | 'shared'>('private');
  const [email, setEmail] = useState('');
  const [permissions, setPermissions] = useState<'read' | 'write'>('read');
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleShare = async () => {
    try {
      setError('');
      // TODO: Implémenter la recherche d'utilisateur par email
      const recipientId = 'user_id_from_email';
      await CodeService.shareCode(snippetId, recipientId, permissions);
      onClose();
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Erreur lors du partage');
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-md">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">Partager le code</h3>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Visibilité
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                className={`flex items-center justify-center p-2 rounded ${
                  visibility === 'private' ? 'bg-blue-100 text-blue-600' : 'bg-gray-100'
                }`}
                onClick={() => setVisibility('private')}
              >
                <Lock className="w-4 h-4 mr-2" />
                Privé
              </button>
              <button
                className={`flex items-center justify-center p-2 rounded ${
                  visibility === 'shared' ? 'bg-blue-100 text-blue-600' : 'bg-gray-100'
                }`}
                onClick={() => setVisibility('shared')}
              >
                <Users className="w-4 h-4 mr-2" />
                Partagé
              </button>
              <button
                className={`flex items-center justify-center p-2 rounded ${
                  visibility === 'public' ? 'bg-blue-100 text-blue-600' : 'bg-gray-100'
                }`}
                onClick={() => setVisibility('public')}
              >
                <Globe className="w-4 h-4 mr-2" />
                Public
              </button>
            </div>
          </div>

          {visibility === 'shared' && (
            <>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Email du destinataire
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3 py-2 border rounded-md"
                  placeholder="exemple@email.com"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Permissions
                </label>
                <select
                  value={permissions}
                  onChange={(e) => setPermissions(e.target.value as 'read' | 'write')}
                  className="w-full px-3 py-2 border rounded-md"
                >
                  <option value="read">Lecture seule</option>
                  <option value="write">Lecture et écriture</option>
                </select>
              </div>
            </>
          )}

          {error && (
            <div className="text-red-600 text-sm">
              {error}
            </div>
          )}

          <div className="flex justify-end space-x-2 mt-4">
            <Button variant="secondary" onClick={onClose}>
              Annuler
            </Button>
            <Button onClick={handleShare}>
              <Share2 className="w-4 h-4 mr-2" />
              Partager
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}