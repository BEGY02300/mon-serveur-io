import { Upload } from 'lucide-react';
import Button from '../ui/Button';

interface FileUploaderProps {
  onUpload: (content: string) => void;
}

export default function FileUploader({ onUpload }: FileUploaderProps) {
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      onUpload(content);
    };
    reader.readAsText(file);
  };

  return (
    <div className="relative">
      <input
        type="file"
        onChange={handleFileChange}
        className="hidden"
        id="file-upload"
        accept=".js,.ts,.jsx,.tsx,.html,.css,.json,.md"
      />
      <label htmlFor="file-upload">
        <Button as="span">
          <Upload className="w-4 h-4 mr-2" />
          Importer
        </Button>
      </label>
    </div>
  );
}