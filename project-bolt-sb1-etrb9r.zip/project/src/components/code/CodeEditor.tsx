import Editor from '@monaco-editor/react';
import { useState, useRef, useEffect } from 'react';
import { Download, Upload, Play, Save, Share2, Eye, Code2 } from 'lucide-react';
import Button from '../ui/Button';
import { saveAs } from 'file-saver';
import JSZip from 'jszip';
import { transform } from '@babel/standalone';
import { useAuth } from '../../context/AuthContext';
import ShareDialog from './ShareDialog';
import PreviewPanel from './PreviewPanel';
import { CodeService } from '../../services/code.service';
import { SUPPORTED_LANGUAGES } from '../../constants/languages';
import FileUploader from './FileUploader';

export default function CodeEditor() {
  const { user } = useAuth();
  const [code, setCode] = useState('// Écrivez votre code ici\n');
  const [language, setLanguage] = useState('javascript');
  const [fileName, setFileName] = useState('code');
  const [preview, setPreview] = useState<string | null>(null);
  const [isShareDialogOpen, setIsShareDialogOpen] = useState(false);
  const [currentSnippetId, setCurrentSnippetId] = useState<string | null>(null);
  const [isPreviewVisible, setIsPreviewVisible] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const editorRef = useRef<any>(null);
  const previewFrameRef = useRef<HTMLIFrameElement>(null);

  const handleEditorDidMount = (editor: any) => {
    editorRef.current = editor;
  };

  const handleCodeChange = (value: string | undefined) => {
    if (value) {
      setCode(value);
      if (language === 'html') {
        updatePreview(value);
      }
    }
  };

  const updatePreview = (content: string) => {
    try {
      if (language === 'html') {
        setPreview(content);
      } else if (language === 'javascript') {
        // Transpile et exécute le JavaScript
        const transpiledCode = transform(content, {
          presets: ['env', 'react'],
        }).code;
        setPreview(`
          <div id="output"></div>
          <script>
            try {
              ${transpiledCode}
            } catch (error) {
              document.getElementById('output').innerHTML = 
                '<pre style="color: red;">Error: ' + error.message + '</pre>';
            }
          </script>
        `);
      }
    } catch (error) {
      console.error('Preview error:', error);
      setPreview(`<pre style="color: red;">Error: ${error instanceof Error ? error.message : 'Unknown error'}</pre>`);
    }
  };

  const handleLanguageChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    setLanguage(event.target.value);
    setPreview(null);
  };

  const saveToCloud = async () => {
    if (!user) return;
    
    try {
      setIsSaving(true);
      const snippetId = await CodeService.saveCode({
        title: fileName,
        code,
        language,
        visibility: 'private'
      }, user.id);
      
      setCurrentSnippetId(snippetId);
      alert('Code sauvegardé avec succès !');
    } catch (error) {
      alert(error instanceof Error ? error.message : 'Erreur lors de la sauvegarde');
    } finally {
      setIsSaving(false);
    }
  };

  const downloadCode = () => {
    const blob = new Blob([code], { type: 'text/plain;charset=utf-8' });
    saveAs(blob, `${fileName}.${language}`);
  };

  const downloadAsZip = async () => {
    const zip = new JSZip();
    zip.file(`${fileName}.${language}`, code);
    const content = await zip.generateAsync({ type: 'blob' });
    saveAs(content, `${fileName}.zip`);
  };

  const handleFileUpload = (content: string) => {
    setCode(content);
  };

  const runCode = () => {
    updatePreview(code);
    setIsPreviewVisible(true);
  };

  return (
    <div className="h-screen flex flex-col">
      <div className="border-b border-gray-200 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <input
              type="text"
              value={fileName}
              onChange={(e) => setFileName(e.target.value)}
              className="px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Nom du fichier"
            />
            <select
              value={language}
              onChange={handleLanguageChange}
              className="px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {Object.entries(SUPPORTED_LANGUAGES).map(([key, value]) => (
                <option key={key} value={key}>{value}</option>
              ))}
            </select>
          </div>

          <div className="flex space-x-2">
            <FileUploader onUpload={handleFileUpload} />
            <Button onClick={downloadCode}>
              <Download className="w-4 h-4 mr-2" />
              Télécharger
            </Button>
            <Button onClick={downloadAsZip}>
              <Download className="w-4 h-4 mr-2" />
              ZIP
            </Button>
            <Button onClick={runCode}>
              <Play className="w-4 h-4 mr-2" />
              Exécuter
            </Button>
            <Button 
              onClick={saveToCloud}
              disabled={isSaving}
            >
              <Save className="w-4 h-4 mr-2" />
              {isSaving ? 'Sauvegarde...' : 'Sauvegarder'}
            </Button>
            {currentSnippetId && (
              <Button 
                variant="secondary" 
                onClick={() => setIsShareDialogOpen(true)}
              >
                <Share2 className="w-4 h-4 mr-2" />
                Partager
              </Button>
            )}
            <Button
              variant="secondary"
              onClick={() => setIsPreviewVisible(!isPreviewVisible)}
            >
              <Eye className="w-4 h-4 mr-2" />
              {isPreviewVisible ? 'Masquer' : 'Aperçu'}
            </Button>
          </div>
        </div>
      </div>

      <div className="flex-1 flex">
        <div className={`flex-1 ${isPreviewVisible ? 'w-1/2' : 'w-full'}`}>
          <Editor
            height="100%"
            defaultLanguage="javascript"
            language={language}
            value={code}
            onChange={handleCodeChange}
            onMount={handleEditorDidMount}
            theme="vs-dark"
            options={{
              minimap: { enabled: false },
              fontSize: 14,
              lineNumbers: 'on',
              automaticLayout: true,
            }}
          />
        </div>
        
        {isPreviewVisible && (
          <PreviewPanel
            preview={preview}
            language={language}
            onClose={() => setIsPreviewVisible(false)}
          />
        )}
      </div>

      {currentSnippetId && (
        <ShareDialog
          snippetId={currentSnippetId}
          isOpen={isShareDialogOpen}
          onClose={() => setIsShareDialogOpen(false)}
        />
      )}
    </div>
  );
}