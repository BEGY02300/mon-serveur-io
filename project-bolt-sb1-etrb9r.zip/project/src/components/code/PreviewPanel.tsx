import { X } from 'lucide-react';
import Button from '../ui/Button';

interface PreviewPanelProps {
  preview: string | null;
  language: string;
  onClose: () => void;
}

export default function PreviewPanel({ preview, language, onClose }: PreviewPanelProps) {
  return (
    <div className="w-1/2 border-l border-gray-200 bg-white">
      <div className="p-4 border-b border-gray-200 flex justify-between items-center">
        <h3 className="font-semibold">Aperçu</h3>
        <Button variant="ghost" onClick={onClose}>
          <X className="w-4 h-4" />
        </Button>
      </div>
      <div className="h-full">
        {language === 'html' || language === 'javascript' ? (
          <iframe
            srcDoc={preview || '<div>Aucun aperçu disponible</div>'}
            className="w-full h-full border-none"
            sandbox="allow-scripts allow-same-origin"
            title="preview"
          />
        ) : (
          <div className="p-4 text-gray-500">
            L'aperçu n'est pas disponible pour ce langage
          </div>
        )}
      </div>
    </div>
  );
}