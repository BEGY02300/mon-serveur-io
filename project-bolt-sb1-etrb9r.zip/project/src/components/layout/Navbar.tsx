import { Code2, LogOut, User } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import Button from '../ui/Button';
import { useAuth } from '../../context/AuthContext';

export default function Navbar() {
  const { isAuthenticated, logout, user } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    try {
      await logout();
      navigate('/login');
    } catch (error) {
      console.error('Erreur lors de la déconnexion:', error);
    }
  };

  return (
    <nav className="border-b border-gray-200 bg-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 justify-between">
          <div className="flex">
            <Link to="/" className="flex items-center">
              <Code2 className="h-8 w-8 text-blue-600" />
              <span className="ml-2 text-xl font-bold">CodeShare</span>
            </Link>

            {isAuthenticated && (
              <div className="ml-10 flex items-center space-x-4">
                <Link
                  to="/editor"
                  className="px-3 py-2 text-gray-700 hover:text-blue-600"
                >
                  Coder
                </Link>
                <Link
                  to="/share"
                  className="px-3 py-2 text-gray-700 hover:text-blue-600"
                >
                  Partager
                </Link>
                <Link
                  to="/resources"
                  className="px-3 py-2 text-gray-700 hover:text-blue-600"
                >
                  Ressources
                </Link>
              </div>
            )}
          </div>

          <div className="flex items-center space-x-4">
            {isAuthenticated ? (
              <>
                <Link to="/profile">
                  <div className="flex items-center space-x-2">
                    <div className="h-8 w-8 overflow-hidden rounded-full">
                      {user?.avatarUrl ? (
                        <img
                          src={user.avatarUrl}
                          alt={user.username}
                          className="h-full w-full object-cover"
                        />
                      ) : (
                        <div className="flex h-full w-full items-center justify-center bg-blue-600 text-white">
                          {user?.username[0].toUpperCase()}
                        </div>
                      )}
                    </div>
                    <span className="text-sm font-medium text-gray-700">
                      {user?.username}
                    </span>
                  </div>
                </Link>
                <Button variant="ghost" onClick={handleLogout}>
                  <LogOut className="h-5 w-5" />
                </Button>
              </>
            ) : (
              <Link to="/login">
                <Button variant="ghost">
                  <User className="h-5 w-5" />
                  Se connecter
                </Button>
              </Link>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}