import { Code2, Zap, Users, Video, Shield, Star, Check, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import Button from '../ui/Button';
import { grades } from '../../data/grades';

export default function ShowcasePage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-gradient-to-r from-blue-600 to-indigo-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <h1 className="text-5xl font-extrabold text-white sm:text-6xl">
              Codez. Apprenez. <span className="text-yellow-400">Évoluez.</span>
            </h1>
            <p className="mt-4 text-xl text-gray-100 max-w-2xl mx-auto">
              Une plateforme complète pour les développeurs, du débutant à l'expert.
              Découvrez un nouvel univers de programmation avec notre IA avancée.
            </p>
            <div className="mt-8 flex justify-center space-x-4">
              <Link to="/register">
                <Button size="lg" className="bg-yellow-400 hover:bg-yellow-500 text-gray-900">
                  Commencer Gratuitement
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link to="/login">
                <Button variant="secondary" size="lg" className="bg-white text-gray-900">
                  Se Connecter
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Features Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <h2 className="text-3xl font-bold text-center mb-12">
          Tout ce dont vous avez besoin pour réussir
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <div className="bg-white p-8 rounded-xl shadow-md hover:shadow-lg transition-all transform hover:-translate-y-1">
            <Code2 className="h-12 w-12 text-blue-600 mb-4" />
            <h3 className="text-xl font-bold mb-2">IA Copilot Avancé</h3>
            <p className="text-gray-600">
              Un assistant IA qui comprend votre code, suggère des améliorations et vous aide à résoudre les bugs.
            </p>
          </div>

          <div className="bg-white p-8 rounded-xl shadow-md hover:shadow-lg transition-all transform hover:-translate-y-1">
            <Video className="h-12 w-12 text-green-600 mb-4" />
            <h3 className="text-xl font-bold mb-2">Cours Vidéo 4K/8K</h3>
            <p className="text-gray-600">
              Des milliers d'heures de contenu éducatif en ultra haute qualité, avec des experts reconnus.
            </p>
          </div>

          <div className="bg-white p-8 rounded-xl shadow-md hover:shadow-lg transition-all transform hover:-translate-y-1">
            <Users className="h-12 w-12 text-purple-600 mb-4" />
            <h3 className="text-xl font-bold mb-2">Mentorat Personnalisé</h3>
            <p className="text-gray-600">
              Un accompagnement sur mesure avec des développeurs expérimentés pour accélérer votre progression.
            </p>
          </div>
        </div>
      </div>

      {/* Popular Grades */}
      <div className="bg-gray-50 py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-4">Choisissez votre niveau</h2>
          <p className="text-center text-gray-600 mb-12 max-w-2xl mx-auto">
            Des offres adaptées à tous les niveaux et besoins, avec la possibilité d'évoluer à votre rythme.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[grades[0], grades[4], grades[9]].map((grade) => (
              <div key={grade.id} className="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-all transform hover:-translate-y-1">
                <div className="text-center">
                  <h3 className={`text-2xl font-bold mb-2 text-${grade.color}-600`}>{grade.name}</h3>
                  <p className="text-3xl font-bold mb-4">
                    {grade.price === 0 ? 'Gratuit' : `${grade.price}€`}
                    <span className="text-sm text-gray-500">/mois</span>
                  </p>
                </div>

                <div className="space-y-4 my-6">
                  <div className="p-3 bg-gray-50 rounded-lg">
                    <p className="text-sm font-medium">Qualité vidéo</p>
                    <p className="text-lg font-semibold text-blue-600">{grade.videoQuality}</p>
                  </div>
                  <div className="p-3 bg-gray-50 rounded-lg">
                    <p className="text-sm font-medium">Projets</p>
                    <p className="text-lg font-semibold text-green-600">
                      {grade.maxProjects === -1 ? 'Illimités' : grade.maxProjects}
                    </p>
                  </div>
                </div>

                <ul className="space-y-3 mb-8">
                  {grade.features.map((feature, index) => (
                    <li key={index} className="flex items-center text-sm">
                      <Check className="h-4 w-4 text-green-500 mr-2" />
                      {feature}
                    </li>
                  ))}
                </ul>

                <Link to="/register" className="block">
                  <Button className="w-full">
                    Commencer avec {grade.name}
                  </Button>
                </Link>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-gradient-to-r from-purple-600 to-indigo-700 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Prêt à commencer votre voyage ?
          </h2>
          <p className="text-xl text-gray-100 mb-8 max-w-2xl mx-auto">
            Rejoignez des milliers de développeurs qui ont déjà transformé leur carrière avec notre plateforme.
          </p>
          <Link to="/register">
            <Button size="lg" className="bg-white text-gray-900 hover:bg-gray-100">
              Commencer Gratuitement
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}