import { UserGrade } from '../../types/user';
import Button from '../ui/Button';
import { Check, Star, Code, Video, HardDrive, Users } from 'lucide-react';

interface GradeCardProps {
  grade: UserGrade;
  isActive: boolean;
  onSelect: () => void;
}

export default function GradeCard({ grade, isActive, onSelect }: GradeCardProps) {
  const getGradeIcon = (feature: string) => {
    if (feature.includes('vidéo') || feature.includes('streaming')) return <Video className="h-4 w-4 text-blue-500" />;
    if (feature.includes('code') || feature.includes('IA')) return <Code className="h-4 w-4 text-green-500" />;
    if (feature.includes('stockage') || feature.includes('GB')) return <HardDrive className="h-4 w-4 text-purple-500" />;
    if (feature.includes('support') || feature.includes('mentorat')) return <Users className="h-4 w-4 text-orange-500" />;
    return <Star className="h-4 w-4 text-yellow-500" />;
  };

  return (
    <div className={`
      relative p-6 rounded-lg border-2 transition-all hover:transform hover:scale-105
      ${isActive ? `border-${grade.color}-500 shadow-lg` : 'border-gray-200'}
      bg-gradient-to-br from-white to-gray-50
    `}>
      {isActive && (
        <div className="absolute -top-3 -right-3 bg-green-500 rounded-full p-1">
          <Check className="h-4 w-4 text-white" />
        </div>
      )}

      <div className="text-center mb-4">
        <h3 className={`text-2xl font-bold mb-2 text-${grade.color}-600`}>{grade.name}</h3>
        <p className="text-3xl font-bold mb-2">
          {grade.price === 0 ? 'Gratuit' : `${grade.price}€`}
          <span className="text-sm text-gray-500">/mois</span>
        </p>
      </div>

      <div className="space-y-4 mb-6">
        <div className="p-2 bg-gray-50 rounded-lg">
          <p className="text-sm font-medium text-gray-700">Qualité vidéo</p>
          <p className="text-lg font-semibold text-blue-600">{grade.videoQuality}</p>
        </div>

        <div className="p-2 bg-gray-50 rounded-lg">
          <p className="text-sm font-medium text-gray-700">Projets</p>
          <p className="text-lg font-semibold text-green-600">
            {grade.maxProjects === -1 ? 'Illimités' : grade.maxProjects}
          </p>
        </div>

        <div className="p-2 bg-gray-50 rounded-lg">
          <p className="text-sm font-medium text-gray-700">Personnalisation</p>
          <p className="text-lg font-semibold text-purple-600">
            {grade.customizationSlots === -1 ? 'Illimitée' : `${grade.customizationSlots} slots`}
          </p>
        </div>
      </div>

      <ul className="space-y-3 mb-6">
        {grade.features.map((feature, index) => (
          <li key={index} className="flex items-center text-sm">
            {getGradeIcon(feature)}
            <span className="ml-2">{feature}</span>
          </li>
        ))}
      </ul>

      <Button
        onClick={onSelect}
        variant={isActive ? "secondary" : "primary"}
        className="w-full"
      >
        {isActive ? 'Grade actuel' : 'Sélectionner'}
      </Button>
    </div>
  );
}