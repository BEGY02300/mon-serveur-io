import { useState } from 'react';
import { CustomizationItem, CustomizationType, UserProfile } from '../../types/user';
import { customizationItems } from '../../data/customization';
import { Coins, Star } from 'lucide-react';
import Button from '../ui/Button';

interface CustomizationPanelProps {
  user: UserProfile;
  onPurchase: (itemId: string) => Promise<void>;
  onEquip: (itemId: string) => Promise<void>;
}

export default function CustomizationPanel({ user, onPurchase, onEquip }: CustomizationPanelProps) {
  const [selectedType, setSelectedType] = useState<CustomizationType>(CustomizationType.Avatar);

  const filteredItems = customizationItems.filter(item => item.type === selectedType);

  return (
    <div className="bg-white shadow rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold">Personnalisation</h3>
        <div className="flex items-center space-x-4">
          <div className="flex items-center">
            <Coins className="h-5 w-5 text-yellow-500 mr-1" />
            <span className="font-bold">{user.coins}</span>
          </div>
          <div className="flex items-center">
            <Star className="h-5 w-5 text-purple-500 mr-1" />
            <span className="font-bold">Niveau {user.level}</span>
          </div>
        </div>
      </div>

      <div className="flex space-x-2 mb-6">
        {Object.values(CustomizationType).map(type => (
          <Button
            key={type}
            variant={selectedType === type ? 'primary' : 'secondary'}
            onClick={() => setSelectedType(type)}
          >
            {type.charAt(0).toUpperCase() + type.slice(1)}
          </Button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {filteredItems.map(item => (
          <div
            key={item.id}
            className="border rounded-lg p-4 flex flex-col items-center"
          >
            <img
              src={item.imageUrl}
              alt={item.name}
              className="w-24 h-24 object-cover rounded-lg mb-2"
            />
            <h4 className="font-bold">{item.name}</h4>
            
            <div className="flex items-center mt-2 mb-4">
              <Coins className="h-4 w-4 text-yellow-500 mr-1" />
              <span>{item.price}</span>
            </div>

            {user.customization.ownedItems.includes(item.id) ? (
              <Button
                variant={user.customization.activeItems.includes(item.id) ? 'secondary' : 'primary'}
                onClick={() => onEquip(item.id)}
              >
                {user.customization.activeItems.includes(item.id) ? 'Équipé' : 'Équiper'}
              </Button>
            ) : (
              <Button
                variant="primary"
                onClick={() => onPurchase(item.id)}
                disabled={user.coins < item.price}
              >
                Acheter
              </Button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}