import { useState, useRef, ChangeEvent } from 'react';
import { useAuth } from '../../context/AuthContext';
import Button from '../ui/Button';
import { Camera, Loader2, Phone, Mail, Crown } from 'lucide-react';
import AuthError from '../auth/AuthError';
import { grades } from '../../data/grades';
import GradeCard from './GradeCard';

export default function ProfilePage() {
  const { user, updateProfile, uploadAvatar } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [formData, setFormData] = useState({
    username: user?.username || '',
    email: user?.email || '',
    recoveryEmail: user?.recoveryEmail || '',
    phoneNumber: user?.phoneNumber || ''
  });

  const handleAvatarClick = () => {
    fileInputRef.current?.click();
  };

  const handleAvatarChange = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setError('Veuillez sélectionner une image');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      setError('L\'image ne doit pas dépasser 5MB');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      const avatarUrl = await uploadAvatar(file);
      await updateProfile({ avatarUrl });
    } catch (err) {
      setError('Erreur lors du téléchargement de l\'image');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      await updateProfile(formData);
      setIsEditing(false);
    } catch (err) {
      setError('Erreur lors de la mise à jour du profil');
    } finally {
      setIsLoading(false);
    }
  };

  const handleGradeSelect = async (gradeId: string) => {
    if (gradeId === user?.grade) return;
    
    setIsLoading(true);
    setError('');

    try {
      await updateProfile({ grade: gradeId });
    } catch (err) {
      setError('Erreur lors de la mise à jour du grade');
    } finally {
      setIsLoading(false);
    }
  };

  if (!user) {
    return null;
  }

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
      <div className="space-y-8">
        {/* Section Profile */}
        <div className="bg-white shadow rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            {error && <AuthError message={error} />}
            
            <div className="flex items-center space-x-6">
              <div className="relative">
                <div 
                  className="h-24 w-24 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden cursor-pointer hover:opacity-90 transition-opacity"
                  onClick={handleAvatarClick}
                >
                  {isLoading ? (
                    <Loader2 className="h-8 w-8 text-gray-400 animate-spin" />
                  ) : user.avatarUrl ? (
                    <img 
                      src={user.avatarUrl} 
                      alt={user.username} 
                      className="h-full w-full object-cover"
                    />
                  ) : (
                    <span className="text-3xl text-gray-500">
                      {user.username[0].toUpperCase()}
                    </span>
                  )}
                </div>
                <button 
                  className="absolute bottom-0 right-0 rounded-full bg-blue-600 p-2 text-white hover:bg-blue-700 transition-colors"
                  onClick={handleAvatarClick}
                >
                  <Camera className="h-4 w-4" />
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleAvatarChange}
                />
              </div>
              
              <div>
                <h2 className="text-2xl font-bold flex items-center">
                  {user.username}
                  <Crown className="ml-2 h-5 w-5 text-yellow-500" />
                </h2>
                <p className="text-gray-600">
                  Membre depuis le {new Date(user.createdAt).toLocaleDateString('fr-FR', {
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric'
                  })}
                </p>
              </div>
            </div>

            {isEditing ? (
              <form onSubmit={handleSubmit} className="mt-6 space-y-4">
                <div>
                  <label htmlFor="username" className="block text-sm font-medium text-gray-700">
                    Nom d'utilisateur
                  </label>
                  <input
                    type="text"
                    id="username"
                    value={formData.username}
                    onChange={(e) => setFormData(prev => ({ ...prev, username: e.target.value }))}
                    className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                    disabled={isLoading}
                  />
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    value={formData.email}
                    onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                    className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                    disabled={isLoading}
                  />
                </div>

                <div>
                  <label htmlFor="recoveryEmail" className="block text-sm font-medium text-gray-700">
                    Email de récupération
                  </label>
                  <input
                    type="email"
                    id="recoveryEmail"
                    value={formData.recoveryEmail}
                    onChange={(e) => setFormData(prev => ({ ...prev, recoveryEmail: e.target.value }))}
                    className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                    disabled={isLoading}
                  />
                </div>

                <div>
                  <label htmlFor="phoneNumber" className="block text-sm font-medium text-gray-700">
                    Numéro de téléphone
                  </label>
                  <input
                    type="tel"
                    id="phoneNumber"
                    value={formData.phoneNumber}
                    onChange={(e) => setFormData(prev => ({ ...prev, phoneNumber: e.target.value }))}
                    className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                    disabled={isLoading}
                    placeholder="+33612345678"
                  />
                </div>

                <div className="flex space-x-4">
                  <Button 
                    type="submit" 
                    disabled={isLoading}
                  >
                    {isLoading ? 'Sauvegarde...' : 'Sauvegarder'}
                  </Button>
                  <Button 
                    type="button" 
                    variant="secondary" 
                    onClick={() => setIsEditing(false)}
                    disabled={isLoading}
                  >
                    Annuler
                  </Button>
                </div>
              </form>
            ) : (
              <div className="mt-6 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-500">Email</p>
                    <p className="flex items-center">
                      <Mail className="h-4 w-4 mr-2" />
                      {user.email}
                    </p>
                  </div>
                  
                  {user.recoveryEmail && (
                    <div>
                      <p className="text-sm text-gray-500">Email de récupération</p>
                      <p className="flex items-center">
                        <Mail className="h-4 w-4 mr-2" />
                        {user.recoveryEmail}
                      </p>
                    </div>
                  )}
                  
                  {user.phoneNumber && (
                    <div>
                      <p className="text-sm text-gray-500">Téléphone</p>
                      <p className="flex items-center">
                        <Phone className="h-4 w-4 mr-2" />
                        {user.phoneNumber}
                      </p>
                    </div>
                  )}
                </div>

                <Button onClick={() => setIsEditing(true)}>
                  Modifier le profil
                </Button>
              </div>
            )}
          </div>
        </div>

        {/* Section Grades */}
        <div>
          <h2 className="text-2xl font-bold mb-6">Grades disponibles</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {grades.map((grade) => (
              <GradeCard
                key={grade.id}
                grade={grade}
                isActive={user.grade === grade.id}
                onSelect={() => handleGradeSelect(grade.id)}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}