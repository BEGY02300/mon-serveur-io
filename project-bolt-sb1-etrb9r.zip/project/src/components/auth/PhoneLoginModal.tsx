import { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import Button from '../ui/Button';

interface PhoneLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export default function PhoneLoginModal({ isOpen, onClose, onSuccess }: PhoneLoginModalProps) {
  const { loginWithPhone, verifyPhoneCode } = useAuth();
  const [phoneNumber, setPhoneNumber] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [verificationId, setVerificationId] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const handleSendCode = async () => {
    setError('');
    setIsLoading(true);
    try {
      const id = await loginWithPhone(phoneNumber);
      setVerificationId(id);
    } catch (err) {
      setError('Erreur lors de l\'envoi du code');
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyCode = async () => {
    if (!verificationId) return;
    
    setError('');
    setIsLoading(true);
    try {
      await verifyPhoneCode(verificationId, verificationCode);
      onSuccess();
    } catch (err) {
      setError('Code de vérification incorrect');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
      <div className="w-full max-w-md rounded-lg bg-white p-6">
        <h3 className="mb-4 text-lg font-medium">Connexion par téléphone</h3>
        
        {error && (
          <div className="mb-4 rounded-md bg-red-50 p-3">
            <p className="text-sm text-red-700">{error}</p>
          </div>
        )}

        {!verificationId ? (
          <div className="space-y-4">
            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-gray-700">
                Numéro de téléphone
              </label>
              <input
                type="tel"
                id="phone"
                placeholder="+33612345678"
                className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
              />
              <p className="mt-1 text-sm text-gray-500">
                Format international requis (ex: +33612345678)
              </p>
            </div>

            <div className="flex justify-end space-x-3">
              <Button variant="secondary" onClick={onClose}>
                Annuler
              </Button>
              <Button onClick={handleSendCode} disabled={isLoading}>
                {isLoading ? 'Envoi...' : 'Envoyer le code'}
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div>
              <label htmlFor="code" className="block text-sm font-medium text-gray-700">
                Code de vérification
              </label>
              <input
                type="text"
                id="code"
                placeholder="123456"
                className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2"
                value={verificationCode}
                onChange={(e) => setVerificationCode(e.target.value)}
              />
            </div>

            <div className="flex justify-end space-x-3">
              <Button variant="secondary" onClick={onClose}>
                Annuler
              </Button>
              <Button onClick={handleVerifyCode} disabled={isLoading}>
                {isLoading ? 'Vérification...' : 'Vérifier'}
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}